import React, { useState, useMemo } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { IncomingInvoice, OutgoingInvoice, Reconciliation } from '../types';
import { useReconciliation } from '../contexts/ReconciliationContext';
import { useAuth } from '../contexts/AuthContext';
import { useNotification } from '../contexts/NotificationContext';
import { db, seedInitialData } from '../services/dbService';
import { useLiveQuery } from 'dexie-react-hooks';
import Button from '../components/common/Button';
import { useData } from '../contexts/DataContext';
import DataTable from '../components/common/DataTable';

const DATE_TOLERANCE_DAYS = 5;
const AMOUNT_TOLERANCE = 0.01;

type MatchResult = {
    matched: { incoming: IncomingInvoice, outgoing: OutgoingInvoice }[];
    unmatchedIncoming: IncomingInvoice[];
    unmatchedOutgoing: OutgoingInvoice[];
};

const InvoiceTable = ({ title, invoices, type }: { title: string, invoices: (IncomingInvoice | OutgoingInvoice)[], type: 'incoming' | 'outgoing' }) => {
    const { t } = useLanguage();
    const total = invoices.reduce((sum, inv) => sum + inv.tutar, 0);

    return (
        <div className="bg-cnk-panel-light p-4 rounded-xl shadow-sm border border-cnk-border-light flex-grow flex flex-col">
            <h3 className="text-lg font-bold mb-2">{title} ({invoices.length})</h3>
            <div className="overflow-y-auto flex-grow">
                <table className="w-full text-sm">
                    <thead>
                        <tr className="text-left text-cnk-txt-muted-light">
                            <th className="p-2">{type === 'incoming' ? t('supplier') : t('customer')}</th>
                            <th className="p-2">{t('invoiceNo')}</th>
                            <th className="p-2">{t('invoiceDate')}</th>
                            <th className="p-2 text-right">{t('amount')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {invoices.map(inv => (
                            <tr key={inv.id} className="border-t border-cnk-border-light">
                                <td className="p-2">{type === 'incoming' ? (inv as IncomingInvoice).tedarikciAdi : (inv as OutgoingInvoice).musteriAdi}</td>
                                <td className="p-2">{inv.faturaNo}</td>
                                <td className="p-2">{new Date(inv.tarih).toLocaleDateString()}</td>
                                <td className="p-2 text-right font-mono">{inv.tutar.toFixed(2)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div className="border-t border-cnk-border-light mt-2 pt-2 text-right font-bold">
                {t('invoiceListTotal')}: {total.toFixed(2)} TL
            </div>
        </div>
    );
};

const ReconciliationPage = () => {
    const { t } = useLanguage();
    const { addReconciliation, reconciliations } = useReconciliation();
    const { currentUser } = useAuth();
    const { showNotification } = useNotification();
    const { customers } = useData();
    
    const incomingInvoices = useLiveQuery(() => db.incomingInvoices.toArray(), []) || [];
    const outgoingInvoices = useLiveQuery(() => db.outgoingInvoices.toArray(), []) || [];
    
    const [matchResult, setMatchResult] = useState<MatchResult | null>(null);

    const runAutoMatch = () => {
        const matched: { incoming: IncomingInvoice, outgoing: OutgoingInvoice }[] = [];
        const unmatchedIncoming: IncomingInvoice[] = [];
        const unmatchedOutgoing: OutgoingInvoice[] = [...outgoingInvoices];

        for (const inc of incomingInvoices) {
            let foundMatch = false;
            for (let i = 0; i < unmatchedOutgoing.length; i++) {
                const out = unmatchedOutgoing[i];

                const taxMatch = inc.vergiNo === out.vergiNo;
                const amountDiff = Math.abs(inc.tutar - out.tutar);
                const amountMatch = amountDiff <= AMOUNT_TOLERANCE;
                
                const incDate = new Date(inc.tarih);
                const outDate = new Date(out.tarih);
                const dateDiff = Math.abs(incDate.getTime() - outDate.getTime());
                const dateMatch = dateDiff <= DATE_TOLERANCE_DAYS * 24 * 60 * 60 * 1000;

                if (taxMatch && amountMatch && dateMatch) {
                    matched.push({ incoming: inc, outgoing: out });
                    unmatchedOutgoing.splice(i, 1);
                    foundMatch = true;
                    break;
                }
            }
            if (!foundMatch) {
                unmatchedIncoming.push(inc);
            }
        }
        
        if (matched.length === 0) {
            showNotification('noMatchesFound', 'info');
        }

        setMatchResult({ matched, unmatchedIncoming, unmatchedOutgoing });
    };

    const handleCreateReconciliations = async () => {
        if (!matchResult || matchResult.matched.length === 0 || !currentUser) return;

        for (const pair of matchResult.matched) {
            const customer = customers.find(c => c.taxNumber === pair.outgoing.vergiNo);
            
            const reconciliationData: Omit<Reconciliation, 'id' | 'createdAt' | 'createdBy' | 'status'> = {
                customerId: customer ? customer.id : 'unknown',
                type: 'current_account',
                period: new Date(pair.incoming.tarih).toISOString().slice(0, 7),
                amount: pair.incoming.tutar,
                incomingInvoiceId: pair.incoming.id,
                outgoingInvoiceId: pair.outgoing.id,
            };
            await addReconciliation(reconciliationData);
        }
        showNotification('reconciliationSuccess', 'success', { count: String(matchResult.matched.length) });
        setMatchResult(null);
    };

    const getStatusClass = (status: Reconciliation['status']) => {
        switch (status) {
            case 'approved': return 'bg-green-100 text-green-800';
            case 'rejected': return 'bg-red-100 text-red-800';
            case 'sent': return 'bg-blue-100 text-blue-800';
            case 'in_review': return 'bg-purple-100 text-purple-800';
            case 'draft':
            default:
                return 'bg-yellow-100 text-yellow-800';
        }
    };
    
    const reconciliationColumns = [
        { header: t('customer'), accessor: (item: Reconciliation) => customers.find(c => c.id === item.customerId)?.name || t('unknownCustomer') },
        { header: t('period'), accessor: (item: Reconciliation) => item.period },
        { header: t('amount'), accessor: (item: Reconciliation) => item.amount.toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' }) },
        { 
            header: t('status'), 
            accessor: (item: Reconciliation) => (
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusClass(item.status)}`}>
                    {t(item.status)}
                </span>
            )
        },
        { header: t('actions'), accessor: (item: Reconciliation) => <Button size="sm">{t('view')}</Button> }
    ];

    return (
        <div className="space-y-4">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold">{t('reconciliation')}</h1>
                <div className="flex gap-2">
                    <Button onClick={seedInitialData} variant="secondary">{t('loadSampleInvoices')}</Button>
                    <Button onClick={runAutoMatch} icon="fas fa-magic">{t('autoMatch')}</Button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <InvoiceTable title={t('incomingInvoices')} invoices={incomingInvoices} type="incoming" />
                <InvoiceTable title={t('outgoingInvoices')} invoices={outgoingInvoices} type="outgoing" />
            </div>

            {matchResult && (
                 <div className="bg-cnk-panel-light p-4 rounded-xl shadow-sm border border-cnk-border-light">
                     <h2 className="text-xl font-bold mb-4">{t('matchedInvoices')}</h2>
                      <div className="flex gap-2 mb-4">
                          <Button 
                            onClick={handleCreateReconciliations} 
                            disabled={matchResult.matched.length === 0}
                            variant="success"
                            icon="fas fa-check"
                          >
                              {t('createReconciliationsForMatches', { count: String(matchResult.matched.length) })}
                          </Button>
                      </div>
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="md:col-span-2">
                             <table className="w-full text-sm">
                                <thead>
                                    <tr className="text-left text-cnk-txt-muted-light">
                                        <th className="p-2">{t('supplier')}</th>
                                        <th className="p-2">{t('invoiceNo')}</th>
                                        <th className="p-2">{t('amount')}</th>
                                        <th className="p-2 font-bold text-center text-xl">↔</th>
                                        <th className="p-2">{t('customer')}</th>
                                        <th className="p-2">{t('invoiceNo')}</th>
                                        <th className="p-2">{t('amount')}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {matchResult.matched.map(pair => (
                                        <tr key={pair.incoming.id} className="border-t border-cnk-border-light bg-green-500/10">
                                            <td className="p-2">{pair.incoming.tedarikciAdi}</td>
                                            <td className="p-2">{pair.incoming.faturaNo}</td>
                                            <td className="p-2">{pair.incoming.tutar.toFixed(2)}</td>
                                            <td className="p-2 text-center text-green-600 font-bold"><i className="fas fa-check-circle"></i></td>
                                            <td className="p-2">{pair.outgoing.musteriAdi}</td>
                                            <td className="p-2">{pair.outgoing.faturaNo}</td>
                                            <td className="p-2">{pair.outgoing.tutar.toFixed(2)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                             </table>
                        </div>
                        <div className="space-y-4">
                            <InvoiceTable title={t('unmatchedIncoming')} invoices={matchResult.unmatchedIncoming} type="incoming" />
                            <InvoiceTable title={t('unmatchedOutgoing')} invoices={matchResult.unmatchedOutgoing} type="outgoing" />
                        </div>
                     </div>
                 </div>
            )}

            <div className="mt-6">
                <h2 className="text-xl font-bold mb-4">{t('reconciliations')}</h2>
                <DataTable
                    columns={reconciliationColumns}
                    data={reconciliations}
                    emptyStateMessage={t('noReconciliationYet')}
                />
            </div>
        </div>
    );
};

export default ReconciliationPage;