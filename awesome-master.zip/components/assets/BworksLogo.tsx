import React from 'react';

const BworksLogo = () => (
     <svg viewBox="0 0 150 40" xmlns="http://www.w3.org/2000/svg">
        <text x="5" y="30" fontFamily="Arial, sans-serif" fontSize="30" fontWeight="bold" fill="#334155">BWorks</text>
    </svg>
);

export default BworksLogo;
