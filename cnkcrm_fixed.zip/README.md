# CNK CRM – DÜZELTİLMİŞ SÜRÜM

Bu paket, `mutabakat`, `kontrol paneli` ve `ERP entegrasyon` modüllerini **çalışır ve test edilebilir** bir şekilde içerir. Mevcut repodaki dosyaları birebir **değiştirmek** için tasarlandı.

## Nasıl Çalıştırılır
```bash
npm i
npm run dev
```
Tarayıcıda `http://localhost:5173` açılır.

## Modüller
- **Kontrol Paneli**: Toplamlar ve son mutabakatlar.
- **Mutabakat**: Fatura eşleştirme (Vergi No + tarih toleransı ±5 gün + tutar toleransı 0,01 TL).
- **ERP Entegrasyon**: MOCK / WOLVOX / LOGO / MIKRO adapter iskeleti. Bağlantı testi, gelen/giden fatura çekme.

## Kalıcı Veritabanı
- `Dexie` (IndexedDB) kullanır. Tarayıcıyı kapatsanız da veri kalır.
- Örnek veri yüklemek için `Mutabakat` sayfasındaki **"Örnek Fatura Yükle"** butonunu kullanın.

## Dosya Yapısı
```
src/
  pages/
    Dashboard.tsx
    Reconciliation.tsx
    ERPIntegration.tsx
  components/
    DataGrid.tsx
  services/
    db.ts
    erp.ts
  utils/
    reconcile.ts
  App.tsx
  main.tsx
```

## Notlar
- React 18 kullanıldı. "Minified React error #31" tipindeki hataları tetikleyecek anti-pattern’lerden kaçınıldı.
- ERP adapterleri gerçek uç noktalara göre kolayca genişletilebilir (bkz. `services/erp.ts`).