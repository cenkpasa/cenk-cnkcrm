export const DATE_FMT = 'yyyy-MM-dd';
export const MONTH_FMT = 'yyyy-MM';
export const AMOUNT_TOLERANCE = 0.01; // 1 kuruş
export const DATE_TOLERANCE_DAYS = 5; // ±5 gün kabul