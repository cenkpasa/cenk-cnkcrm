export type UUID = string;

export interface Cari {
  id: UUID;
  unvan: string;
  vergiNo: string;
}

export interface Fatura {
  id: UUID;
  cariVergiNo: string;
  cariUnvan: string;
  tarih: string; // ISO yyyy-MM-dd
  tutar: number;
  seri?: string;
  numara?: string;
  tip: 'GELEN' | 'GIDEN';
  erpRef?: string | null;
}

export interface MutabakatKaydi {
  id: UUID;
  cariVergiNo: string;
  cariUnvan: string;
  ay: string; // yyyy-MM
  toplamBorc: number;
  toplamAlacak: number;
  fark: number;
  durum: 'ESLESTI' | 'KISMEN' | 'ESLESMEDI';
  olusanTarih: string;
  eslesenFaturalar: string[]; // fatura ids
}

export interface SyncLog {
  id: UUID;
  adapter: string; // e.g., WOLVOX, LOGO, MIKRO
  islem: 'PULL_IN' | 'PULL_OUT' | 'PUSH_RECON';
  basarili: boolean;
  mesaj: string;
  zaman: string;
}