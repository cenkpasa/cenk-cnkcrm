import { Link, Route, Routes, Navigate, useLocation } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Reconciliation from './pages/Reconciliation'
import ERPIntegration from './pages/ERPIntegration'

export default function App() {
  const loc = useLocation();
  return (
    <div style={{fontFamily:'system-ui, Arial', background:'#f6f7fb', minHeight:'100vh'}}>
      <header style={{background:'#111827', color:'#fff', padding:'12px 20px', display:'flex', alignItems:'center', justifyContent:'space-between'}}>
        <div style={{display:'flex', gap:16, alignItems:'center'}}>
          <strong>CNK CRM</strong>
          <nav style={{display:'flex', gap:12}}>
            <Link style={linkStyle(loc.pathname === '/dashboard')} to="/dashboard">Kontrol Paneli</Link>
            <Link style={linkStyle(loc.pathname === '/reconciliation')} to="/reconciliation">Mutabakat</Link>
            <Link style={linkStyle(loc.pathname === '/erp')} to="/erp">ERP Entegrasyon</Link>
          </nav>
        </div>
      </header>
      <main style={{padding:'20px 24px'}}>
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/reconciliation" element={<Reconciliation />} />
          <Route path="/erp" element={<ERPIntegration />} />
          <Route path="*" element={<div>Sayfa bulunamadı.</div>} />
        </Routes>
      </main>
    </div>
  )
}

function linkStyle(active:boolean): React.CSSProperties {
  return {
    color: active ? '#fff' : '#cbd5e1',
    textDecoration: 'none',
    fontWeight: active ? 700 : 500,
    padding:'6px 10px',
    background: active ? '#6d28d9' : 'transparent',
    borderRadius: 8
  }
}