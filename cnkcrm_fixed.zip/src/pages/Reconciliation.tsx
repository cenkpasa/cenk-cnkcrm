import { useEffect, useMemo, useState } from 'react'
import { format } from 'date-fns'
import { db } from '../services/db'
import { Fatura, MutabakatKaydi } from '../types'
import DataGrid from '../components/DataGrid'
import { autoMatch } from '../utils/reconcile'

export default function Reconciliation(){
  const [incoming, setIncoming] = useState<Fatura[]>([])
  const [outgoing, setOutgoing] = useState<Fatura[]>([])
  const [creating, setCreating] = useState(false)

  useEffect(()=>{
    db.faturalar.where('tip').equals('GELEN').toArray().then(setIncoming)
    db.faturalar.where('tip').equals('GIDEN').toArray().then(setOutgoing)
  }, [])

  const matches = useMemo(()=>autoMatch(incoming, outgoing), [incoming, outgoing])

  async function createReconciliations(){
    setCreating(true)
    try {
      const ay = format(new Date(), 'yyyy-MM')
      for (const m of matches) {
        const cariVergiNo = m.incoming[0]?.cariVergiNo ?? m.outgoing[0]?.cariVergiNo ?? ''
        const cariUnvan = m.incoming[0]?.cariUnvan ?? m.outgoing[0]?.cariUnvan ?? ''
        const toplamBorc = m.incoming.reduce((a,b)=>a+b.tutar,0)
        const toplamAlacak = m.outgoing.reduce((a,b)=>a+b.tutar,0)
        const fark = +(toplamAlacak - toplamBorc).toFixed(2)
        const durum: MutabakatKaydi['durum'] = Math.abs(fark) < 0.01 ? 'ESLESTI' : (m.incoming.length && m.outgoing.length ? 'KISMEN' : 'ESLESMEDI')
        const rec: MutabakatKaydi = {
          id: crypto.randomUUID(),
          cariVergiNo, cariUnvan, ay,
          toplamBorc, toplamAlacak, fark, durum,
          olusanTarih: new Date().toISOString(),
          eslesenFaturalar: [...m.incoming, ...m.outgoing].map(x=>x.id)
        }
        await db.mutabakatlar.add(rec)
      }
      alert('Mutabakatlar oluşturuldu.')
    } finally {
      setCreating(false)
    }
  }

  return (
    <div style={{display:'grid', gap:16}}>
      <div style={{display:'flex', gap:12, alignItems:'center'}}>
        <button onClick={seedSample} style={btn}>Örnek Fatura Yükle</button>
        <button disabled={creating} onClick={createReconciliations} style={btnPrimary}>Mutabakat Oluştur</button>
      </div>

      <section>
        <h3>Eşleşen Kümeler</h3>
        {matches.map((m,i)=>(
          <div key={i} style={{display:'grid', gridTemplateColumns:'1fr 1fr 120px', gap:12, marginBottom:16}}>
            <DataGrid rows={m.incoming} cols={[
              { key:'cariUnvan', title:'Gelen - Cari' },
              { key:'tarih', title:'Tarih' },
              { key:'tutar', title:'Tutar' }
            ]}/>
            <DataGrid rows={m.outgoing} cols={[
              { key:'cariUnvan', title:'Giden - Cari' },
              { key:'tarih', title:'Tarih' },
              { key:'tutar', title:'Tutar' }
            ]}/>
            <div style={{display:'flex', alignItems:'center', justifyContent:'center', background:'#fff', borderRadius:12}}>
              <div style={{textAlign:'center'}}>
                <div style={{fontSize:12, color:'#64748b'}}>Fark</div>
                <div style={{fontSize:20, fontWeight:700}}>{m.fark.toLocaleString('tr-TR', {style:'currency', currency:'TRY'})}</div>
              </div>
            </div>
          </div>
        ))}
        {matches.length===0 && <div style={{color:'#64748b'}}>Eşleşme bulunamadı. Örnek verileri yükleyip tekrar deneyin.</div>}
      </section>
    </div>
  )
}

async function seedSample(){
  // Basit örnek veri
  const today = new Date();
  const iso = (d:Date)=>d.toISOString().slice(0,10)
  const d = (n:number)=>{ const x = new Date(today); x.setDate(x.getDate()-n); return x }
  const arr: Fatura[] = [
    { id: crypto.randomUUID(), cariVergiNo:'1234567890', cariUnvan:'ACME A.Ş.', tarih: iso(d(2)), tutar:1250.5, tip:'GELEN' },
    { id: crypto.randomUUID(), cariVergiNo:'1234567890', cariUnvan:'ACME A.Ş.', tarih: iso(d(4)), tutar:800, tip:'GELEN' },
    { id: crypto.randomUUID(), cariVergiNo:'1112223334', cariUnvan:'BETA LTD', tarih: iso(d(1)), tutar:950.75, tip:'GELEN' },
    { id: crypto.randomUUID(), cariVergiNo:'1234567890', cariUnvan:'ACME A.Ş.', tarih: iso(d(3)), tutar:1250.5, tip:'GIDEN' },
    { id: crypto.randomUUID(), cariVergiNo:'1234567890', cariUnvan:'ACME A.Ş.', tarih: iso(d(5)), tutar:800, tip:'GIDEN' },
  ]
  await db.faturalar.bulkAdd(arr)
  alert('Örnek faturalar yüklendi.')
}

const btn: React.CSSProperties = { padding:'10px 12px', borderRadius:10, border:'1px solid #e5e7eb', background:'#fff', cursor:'pointer' }
const btnPrimary: React.CSSProperties = { ...btn, background:'#6d28d9', color:'#fff', border:'none' }