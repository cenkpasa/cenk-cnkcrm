import { useEffect, useMemo, useState } from 'react'
import { db } from '../services/db'
import { Fatura, MutabakatKaydi } from '../types'
import DataGrid from '../components/DataGrid'

export default function Dashboard() {
  const [incoming, setIncoming] = useState<Fatura[]>([])
  const [outgoing, setOutgoing] = useState<Fatura[]>([])
  const [mutabakatlar, setMutabakatlar] = useState<MutabakatKaydi[]>([])

  useEffect(()=>{
    db.faturalar.where('tip').equals('GELEN').toArray().then(setIncoming)
    db.faturalar.where('tip').equals('GIDEN').toArray().then(setOutgoing)
    db.mutabakatlar.toArray().then(setMutabakatlar)
  }, [])

  const stats = useMemo(()=>{
    const tIn = incoming.reduce((a,b)=>a+b.tutar,0)
    const tOut = outgoing.reduce((a,b)=>a+b.tutar,0)
    const fark = +(tOut - tIn).toFixed(2)
    return { tIn, tOut, fark }
  }, [incoming, outgoing])

  return (
    <div style={{display:'grid', gap:16}}>
      <div style={{display:'grid', gridTemplateColumns:'repeat(3, minmax(0,1fr))', gap:16}}>
        <KPI title="Gelen Toplam" value={stats.tIn.toLocaleString('tr-TR', {style:'currency', currency:'TRY'})} />
        <KPI title="Giden Toplam" value={stats.tOut.toLocaleString('tr-TR', {style:'currency', currency:'TRY'})} />
        <KPI title="Fark" value={stats.fark.toLocaleString('tr-TR', {style:'currency', currency:'TRY'})} />
      </div>

      <section>
        <h3 style={{margin:'8px 0'}}>Son Mutabakatlar</h3>
        <DataGrid rows={mutabakatlar.slice(-10).reverse()} cols={[
          { key:'cariUnvan', title:'Cari' },
          { key:'cariVergiNo', title:'Vergi No' },
          { key:'ay', title:'Ay' },
          { key:'durum', title:'Durum' },
          { key:'fark', title:'Fark' },
        ]}/>
      </section>
    </div>
  )
}

function KPI({title, value}:{title:string; value:string}){
  return (
    <div style={{background:'#fff', padding:16, borderRadius:12, boxShadow:'0 2px 12px rgba(0,0,0,.07)'}}>
      <div style={{color:'#64748b', fontSize:12}}>{title}</div>
      <div style={{fontSize:24, fontWeight:700}}>{value}</div>
    </div>
  )
}