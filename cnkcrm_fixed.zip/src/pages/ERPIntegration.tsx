import { useEffect, useMemo, useState } from 'react'
import { db } from '../services/db'
import { buildAdapter, ERPAdapterName, ERPConfig } from '../services/erp'
import DataGrid from '../components/DataGrid'
import { Fatura } from '../types'
import { format } from 'date-fns'

type PullKind = 'incoming' | 'outgoing'

export default function ERPIntegration() {
  const [adapterName, setAdapterName] = useState<ERPAdapterName>('MOCK')
  const [cfg, setCfg] = useState<ERPConfig>({ baseUrl: '', apiKey: '' })
  const [status, setStatus] = useState<string>('')
  const [rows, setRows] = useState<Fatura[]>([])
  const [from, setFrom] = useState<string>(format(new Date(), 'yyyy-MM-01'))
  const [to, setTo] = useState<string>(new Date().toISOString().slice(0,10))

  const adapter = useMemo(()=>buildAdapter(adapterName, cfg), [adapterName, cfg])

  async function test() {
    const r = await adapter.testConnection()
    setStatus(r.ok ? 'Bağlantı başarılı ✔' : `Hata: ${r.message}`)
  }

  async function pull(kind: PullKind) {
    const items = kind==='incoming'
      ? await adapter.pullIncoming({ from, to })
      : await adapter.pullOutgoing({ from, to })
    if (items.length) await db.faturalar.bulkPut(items)
    setRows(items)
    setStatus(`${items.length} kayıt alındı.`)
  }

  return (
    <div style={{display:'grid', gap:16}}>
      <section style={{display:'grid', gridTemplateColumns:'repeat(2, minmax(0,1fr))', gap:16}}>
        <div style={{background:'#fff', padding:16, borderRadius:12}}>
          <h3>ERP Ayarları</h3>
          <div style={{display:'grid', gap:8}}>
            <label>Adapter
              <select value={adapterName} onChange={e=>setAdapterName(e.target.value as ERPAdapterName)}>
                <option value="MOCK">MOCK</option>
                <option value="WOLVOX">WOLVOX</option>
                <option value="LOGO">LOGO</option>
                <option value="MIKRO">MIKRO</option>
              </select>
            </label>
            <label>Base URL
              <input value={cfg.baseUrl ?? ''} onChange={e=>setCfg(s=>({...s, baseUrl: e.target.value}))} placeholder="https://erp-sunucu.local:8080" />
            </label>
            <label>API Key
              <input value={cfg.apiKey ?? ''} onChange={e=>setCfg(s=>({...s, apiKey: e.target.value}))} />
            </label>
            <div style={{display:'flex', gap:8}}>
              <button onClick={test} style={btn}>Bağlantıyı Test Et</button>
            </div>
            <div style={{color:'#334155'}}>{status}</div>
          </div>
        </div>
        <div style={{background:'#fff', padding:16, borderRadius:12}}>
          <h3>Veri Çek</h3>
          <div style={{display:'flex', gap:8, alignItems:'center', marginBottom:8}}>
            <label>From: <input type="date" value={from} onChange={e=>setFrom(e.target.value)} /></label>
            <label>To: <input type="date" value={to} onChange={e=>setTo(e.target.value)} /></label>
            <button onClick={()=>pull('incoming')} style={btn}>Gelen Fatura Çek</button>
            <button onClick={()=>pull('outgoing')} style={btn}>Giden Fatura Çek</button>
          </div>
          <DataGrid rows={rows} cols={[
            { key:'cariUnvan', title:'Cari' },
            { key:'cariVergiNo', title:'Vergi No' },
            { key:'tarih', title:'Tarih' },
            { key:'tutar', title:'Tutar' },
            { key:'tip', title:'Tip' },
          ]}/>
        </div>
      </section>
    </div>
  )
}

const btn: React.CSSProperties = { padding:'10px 12px', borderRadius:10, border:'1px solid #e5e7eb', background:'#fff', cursor:'pointer' }