import { ReactNode } from 'react'

interface Col<T> {
  key: keyof T
  title: string
  render?: (row: T) => ReactNode
  width?: number | string
}

export default function DataGrid<T extends { id: string }>(
  { rows, cols }: { rows: T[]; cols: Col<T>[] }
) {
  return (
    <div style={{overflowX:'auto', background:'#fff', borderRadius:12, boxShadow:'0 2px 12px rgba(0,0,0,.07)'}}>
      <table style={{width:'100%', borderCollapse:'collapse'}}>
        <thead>
          <tr>
            {cols.map(c=>(
              <th key={String(c.key)} style={{textAlign:'left', padding:10, borderBottom:'1px solid #e5e7eb'}}>{c.title}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map(r=>(
            <tr key={r.id}>
              {cols.map(c=>(
                <td key={String(c.key)} style={{padding:10, borderBottom:'1px solid #f1f5f9'}}>
                  {c.render ? c.render(r) : String(r[c.key])}
                </td>
              ))}
            </tr>
          ))}
          {rows.length===0 && (
            <tr><td colSpan={cols.length} style={{padding:16, textAlign:'center', color:'#6b7280'}}>Kayıt yok</td></tr>
          )}
        </tbody>
      </table>
    </div>
  )
}