import { addDays, differenceInCalendarDays } from 'date-fns'
import { AMOUNT_TOLERANCE, DATE_TOLERANCE_DAYS } from '../constants'
import { Fatura } from '../types'

export interface MatchResult {
  incoming: Fatura[]
  outgoing: Fatura[]
  fark: number
}

/**
 * Basit eşleştirme: vergiNo + (yakın tarih) + tutar toleransı
 */
export function autoMatch(incoming: Fatura[], outgoing: Fatura[]): MatchResult[] {
  const groups = new Map<string, { in: Fatura[]; out: Fatura[] }>()
  const push = (k:string, tip:'in'|'out', f:Fatura)=>{
    const g = groups.get(k) ?? { in:[], out:[] }
    g[tip].push(f); groups.set(k, g)
  }
  for (const f of incoming) push(f.cariVergiNo, 'in', f)
  for (const f of outgoing) push(f.cariVergiNo, 'out', f)

  const results: MatchResult[] = []
  for (const [tax, g] of groups) {
    const inList = [...g.in].sort((a,b)=>a.tarih.localeCompare(b.tarih))
    const outList = [...g.out].sort((a,b)=>a.tarih.localeCompare(b.tarih))
    const usedOut = new Set<string>()
    const matchedIn: Fatura[] = []
    const matchedOut: Fatura[] = []

    for (const fin of inList) {
      const finDate = new Date(fin.tarih)
      const cand = outList.find(fo => !usedOut.has(fo.id) &&
        Math.abs(fo.tutar - fin.tutar) <= AMOUNT_TOLERANCE &&
        Math.abs(differenceInCalendarDays(new Date(fo.tarih), finDate)) <= DATE_TOLERANCE_DAYS)
      if (cand) {
        usedOut.add(cand.id); matchedIn.push(fin); matchedOut.push(cand)
      }
    }

    const sumIn = matchedIn.reduce((a,b)=>a+b.tutar,0)
    const sumOut = matchedOut.reduce((a,b)=>a+b.tutar,0)
    results.push({ incoming: matchedIn, outgoing: matchedOut, fark: +(sumOut - sumIn).toFixed(2) })
  }
  return results
}