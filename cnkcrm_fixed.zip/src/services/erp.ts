import axios from 'axios'
import { Fatura } from '../types'

export type ERPAdapterName = 'WOLVOX' | 'LOGO' | 'MIKRO' | 'MOCK'

export interface ERPAdapter {
  name: ERPAdapterName
  testConnection(): Promise<{ ok: boolean; message?: string }>
  pullIncoming(params: { from: string; to: string }): Promise<Fatura[]>
  pullOutgoing(params: { from: string; to: string }): Promise<Fatura[]>
  pushReconciliation(payload: any): Promise<{ ok: boolean; message?: string }>
}

export interface ERPConfig {
  baseUrl?: string
  apiKey?: string
  username?: string
  password?: string
}

export function buildAdapter(name: ERPAdapterName, cfg: ERPConfig): ERPAdapter {
  if (name === 'WOLVOX') return new WolvoxAdapter(cfg)
  if (name === 'LOGO') return new LogoAdapter(cfg)
  if (name === 'MIKRO') return new MikroAdapter(cfg)
  return new MockAdapter()
}

// ---- MOCK ----
class MockAdapter implements ERPAdapter {
  name: ERPAdapterName = 'MOCK'
  async testConnection() { return { ok: true, message: 'Mock bağlantı OK' } }
  async pullIncoming(): Promise<Fatura[]> { return sample('GELEN') }
  async pullOutgoing(): Promise<Fatura[]> { return sample('GIDEN') }
  async pushReconciliation(): Promise<{ok:boolean; message?:string}> { return { ok: true, message: 'Mock push OK' } }
}

function sample(tip: 'GELEN' | 'GIDEN'): Fatura[] {
  const today = new Date();
  const month = today.toISOString().slice(0,7);
  const d = (n:number)=>{
    const dt = new Date(today); dt.setDate(dt.getDate()-n);
    return dt.toISOString().slice(0,10)
  }
  return [
    { id: crypto.randomUUID(), cariVergiNo:'1234567890', cariUnvan:'ACME A.Ş.', tarih:d(2), tutar: 1250.50, tip },
    { id: crypto.randomUUID(), cariVergiNo:'1234567890', cariUnvan:'ACME A.Ş.', tarih:d(4), tutar: 800.00, tip },
    { id: crypto.randomUUID(), cariVergiNo:'1112223334', cariUnvan:'BETA LTD', tarih:d(1), tutar: 950.75, tip },
  ]
}

// ---- WOLVOX (skeleton) ----
class WolvoxAdapter implements ERPAdapter {
  name: ERPAdapterName = 'WOLVOX'
  constructor(private cfg: ERPConfig) {}
  async testConnection() {
    if (!this.cfg.baseUrl) return { ok:false, message:'Base URL tanımlı değil' }
    try {
      // S: Sağlık kontrolü var sayalım
      const url = `${this.cfg.baseUrl}/health`
      await axios.get(url, { timeout: 4000 })
      return { ok:true, message:'Wolvox bağlantısı OK' }
    } catch (e:any) {
      return { ok:false, message:e?.message ?? 'Bağlantı hatası' }
    }
  }
  async pullIncoming({from, to}:{from:string; to:string}) {
    return this.pullCommon('incoming', from, to)
  }
  async pullOutgoing({from, to}:{from:string; to:string}) {
    return this.pullCommon('outgoing', from, to)
  }
  private async pullCommon(kind: 'incoming'|'outgoing', from:string, to:string): Promise<Fatura[]> {
    if (!this.cfg.baseUrl) return []
    try {
      const url = `${this.cfg.baseUrl}/api/invoices/${kind}?from=${from}&to=${to}`
      const r = await axios.get(url, {
        headers: this.cfg.apiKey ? { 'X-API-KEY': this.cfg.apiKey } : undefined
      })
      const rows = Array.isArray(r.data) ? r.data : []
      return rows.map((x:any)=> ({
        id: x.id ?? crypto.randomUUID(),
        cariVergiNo: x.taxNo ?? '',
        cariUnvan: x.title ?? '',
        tarih: x.date?.slice(0,10) ?? '',
        tutar: Number(x.amount ?? 0),
        seri: x.series,
        numara: x.number,
        tip: kind === 'incoming' ? 'GELEN' : 'GIDEN',
        erpRef: String(x.erpRef ?? '')
      } as Fatura))
    } catch {
      return []
    }
  }
  async pushReconciliation(payload:any) {
    if (!this.cfg.baseUrl) return { ok:false, message:'Base URL yok' }
    try {
      const url = `${this.cfg.baseUrl}/api/reconciliation`
      await axios.post(url, payload, {
        headers: this.cfg.apiKey ? { 'X-API-KEY': this.cfg.apiKey } : undefined
      })
      return { ok:true }
    } catch (e:any) {
      return { ok:false, message: e?.message ?? 'Push hatası' }
    }
  }
}

// ---- LOGO / MIKRO (skeletons) ----
class LogoAdapter extends WolvoxAdapter { name: ERPAdapterName = 'LOGO' }
class MikroAdapter extends WolvoxAdapter { name: ERPAdapterName = 'MIKRO' }