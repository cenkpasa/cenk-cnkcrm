import Dexie, { Table } from 'dexie'
import { Fatura, MutabakatKaydi, SyncLog } from '../types'

export class CRMDb extends Dexie {
  faturalar!: Table<Fatura, string>
  mutabakatlar!: Table<MutabakatKaydi, string>
  syncLog!: Table<SyncLog, string>

  constructor() {
    super('cnkcrm_db')
    this.version(1).stores({
      faturalar: 'id, cariVergiNo, tarih, tutar, tip, erpRef',
      mutabakatlar: 'id, cariVergiNo, ay, durum',
      syncLog: 'id, adapter, islem, zaman'
    })
  }
}

export const db = new CRMDb()